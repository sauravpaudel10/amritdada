from django.shortcuts import render , redirect
from .models import Product
from .forms import UserRegisterForm , ProductUploadForm
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import ListView ,DetailView ,CreateView ,UpdateView ,DeleteView
from django.contrib import messages
from django.urls import reverse_lazy

# Create your views here.


def home(request):
    return render (request , 'home.html' )



def register(request):
    if request.method == 'POST':
        form =UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request,f'Account created for {username}! ')
            return redirect ('home')
    else:
       form = UserRegisterForm()
    content = {'form' : form}
    return render (request, 'register.html',content)




class ProductListView(ListView):
     model = Product
     template_name = 'product.html'
     context_object_name = 'products'
     ordering = ['-dateposted']



class ProductDetailView(DetailView):
     model = Product
     template_name = 'productdetail.html'

     
class ProductCreateView(LoginRequiredMixin , ProductUploadForm,CreateView):
    model = Product
    template_name = 'postform.html'



    def form_valid (self ,form):
        form.instance.author = self.request.user
        return super().form_valid(form)
   


        

class ProductUpdateView(LoginRequiredMixin, UserPassesTestMixin,ProductUploadForm ,UpdateView):
    model = Product
    template_name = 'postform.html'

    def form_valid (self ,form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True      
        return False
   


class ProductDeleteView(LoginRequiredMixin, UserPassesTestMixin ,DeleteView):
     model = Product
     template_name = 'productdelete.html'
     success_url = reverse_lazy('product')

     def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False
