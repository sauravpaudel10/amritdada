from django.urls import path

from . import views
from django.contrib.auth import views as auth_views
from .views import (ProductListView,
ProductDetailView,ProductCreateView,ProductUpdateView,
ProductDeleteView)


from django.views.generic import TemplateView



urlpatterns = [
path('', TemplateView.as_view(template_name='home.html') , name='home'),
path('product/' , ProductListView.as_view(), name ='product'),
path('product/<int:pk>/' , ProductDetailView.as_view() , name='productdetail'),
path('productcreate/' , ProductCreateView.as_view() , name='productcreate'),
path('product/<int:pk>/update/' , ProductUpdateView.as_view() , name='productupdate'),
path('product/<int:pk>/delete/' , ProductDeleteView.as_view() , name='productdelete'),
path('register/' , views.register, name ='register'),
path('login/',auth_views.LoginView.as_view(template_name ='login.html'), name = 'login'),
path('logout/',auth_views.LogoutView.as_view(template_name ='logout.html'), name='logout'),
path('<path:invalid_path>', TemplateView.as_view(template_name='page_doesnot_exist.html'), name='does_not_exist'),



]